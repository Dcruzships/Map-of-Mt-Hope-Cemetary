# Map of Mt Hope Cemetary
 An interactive map of Mt. Hope Cemetary in Rochester, NY
